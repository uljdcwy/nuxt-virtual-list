import { defineNuxtConfig } from 'nuxt'

export default defineNuxtConfig({
  ssr: false,
  app: {
    head: {
      title: 'Nuxt Virtual List Demo'
    }
  }
})
